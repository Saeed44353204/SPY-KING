![code](https://img.shields.io/static/v1.svg?label=Code&message=KING-HACKING&color=red?style=plastic&logo=appveyor)
![version](https://img.shields.io/static/v1.svg?label=Version&message=1.0&color=green?style=plastic&logo=appveyor)
![python](https://img.shields.io/static/v1.svg?label=Python&message=2.7,3.7&color=green?style=plastic&logo=appveyor)
![linux](https://img.shields.io/static/v1.svg?label=Supported_OS&message=Linux&color=orange?style=plastic&logo=appveyor)
## Remote Administration Tool For OS Linux
## How To Use
```
apt-get install pytho2 && apt-get install python3
git clone https://github.com/king-hacking/SPY-KING.git
cd SPY-KING
python3 SPY-KING.py
```
* Screenshot of the tool
![#1](https://a.top4top.net/p_1202ntd9v1.jpg)

Core Commands
=============

    Command          Description
    -------          -----------
    ps               : List running processes
    exit             : Exit the console
    help             : Help menu
    clear            : clean all commands
File system Commands
====================

    Command          Description
    -------          -----------
    cd               : Change directory on Target
    lcd              : Change directory on your file
    copy             : Copy source to destination
    ls               : List files on Target
    lls              : List yor file
    move             : Move source to destination
    del              : Delete the specified file
    delall           : Delete All Files in Path
    cat              : Read the contents of a file to the screen
    pwd              : Print working directory
    mkdir            : Make directory
    makedirs         : Make lots of files (ex: makedirs 10)
    rename           : ReName Any File or directory
    del              : Dellet directory
    download         : Download a file or directory
    upload           : Upload a file or directory
System Commands
===============

    Command          Description
    -------          -----------
    pid              : get process id
    cpu              : Show Info CPU Target
    shell            : Drop into a system command shell
    crypto           : Show Encoding On Target
    hostname         : get host name
    use_momery       : Show Use Memory Target
    mem_info         : Show Info Memory Target
    kernel           : Show Kernel Version + Info
    info_phone       : Gets information about the remote system
    localtime        : Displays the target system's local time
    getuid           : Get the user that the server is running as
    partitions       : Check Info Partisi On Target
Networking Commands
===================

    Command          Description
    -------          -----------
    ifconfig         : Display interfaces
    net_info         : check network card & show ip address
    mac_wifi         : Show Mac Address The Wifi Target
    mac_bluetooth    : Show Mac Address The bluetooth Target
    ip_address       : Get IP address Target
    scan_port        : Get Ports open and closeed on Target
    info_target      : Get information about where the target
Android Commands
================

    Command          Description
    -------          -----------
    check_root       : Show info Root Target
**My Accounts**
===========
* [Whatsapp](https://api.whatsapp.com/send?phone=963937376654)
* [FACEBOOK](https://www.facebook.com/KING.HACKING.SY)
* [TELEGRAM](https://t.me/HACKEER1)
* [INSTAGRAM](https://instagram.com/king1hacking)
